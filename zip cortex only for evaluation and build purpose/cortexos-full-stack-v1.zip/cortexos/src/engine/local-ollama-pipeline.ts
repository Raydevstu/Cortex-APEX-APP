// Step 2: Local Ollama Structured-Output Pipeline (Router + Prompt Engineer + Memory Extractor)
import fs from 'node:fs/promises';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import type {
  ProjectDNA,
  RouterDecision,
  Tier1RewrittenPrompt,
  ExtractedMemoryDelta,
  TaskScopeLock
} from '../types/cortex-contracts.js';

const execFileAsync = promisify(execFile);

export class LocalOllamaPipeline {
  private readonly repoRoot: string;

  constructor(repoRoot: string = process.cwd()) {
    this.repoRoot = repoRoot;
  }

  public async loadProjectDNA(): Promise<ProjectDNA> {
    const dnaPath = path.join(this.repoRoot, '.cortex', 'project-dna.json');
    const raw = await fs.readFile(dnaPath, 'utf-8');
    return JSON.parse(raw) as ProjectDNA;
  }

  private async callOllamaStructured<T>(
    model: string,
    systemPromptPath: string,
    schemaPath: string,
    userPayload: Record<string, unknown>,
    baseUrl: string
  ): Promise<T> {
    const [systemPrompt, schemaRaw] = await Promise.all([
      fs.readFile(path.join(this.repoRoot, systemPromptPath), 'utf-8'),
      fs.readFile(path.join(this.repoRoot, schemaPath), 'utf-8')
    ]);

    const response = await fetch(`${baseUrl}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model,
        stream: false,
        format: JSON.parse(schemaRaw),
        options: { temperature: 0.1, num_ctx: 8192 },
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: JSON.stringify(userPayload) }
        ]
      })
    });

    if (!response.ok) {
      throw new Error(`Ollama API error (${response.status}): ${await response.text()}`);
    }

    const body = (await response.json()) as { message?: { content?: string } };
    return JSON.parse(body.message?.content ?? '{}') as T;
  }

  public async routeRequest(rawUserPrompt: string, activeFiles: string[]): Promise<RouterDecision> {
    const dna = await this.loadProjectDNA();
    return this.callOllamaStructured<RouterDecision>(
      dna.agentRouting.models.router,
      '.cortex/prompts/pre-execution-router.system.md',
      '.cortex/schemas/router-decision.schema.json',
      { rawUserPrompt, activeFiles, techStack: dna.techStack },
      dna.agentRouting.ollamaBaseUrl
    );
  }

  public async runLocalPreExecutionTools(decision: RouterDecision): Promise<Record<string, string>> {
    const results: Record<string, string> = {};
    for (const tool of decision.localToolsToRun) {
      try {
        if (tool === 'git_diff') {
          const { stdout } = await execFileAsync('git', ['diff', '--stat'], { cwd: this.repoRoot });
          results.git_diff = stdout.trim().slice(0, 1500);
        } else if (tool === 'ast_outline') {
          results.ast_outline = `Scanned target files: ${decision.targetFiles.join(', ')}`;
        }
      } catch (err) {
        results[tool] = `Tool ${tool} skipped: ${(err as Error).message}`;
      }
    }
    return results;
  }

  public async rewritePromptTier1(
    rawUserPrompt: string,
    scopedGraphContext: string,
    preExecOutput: Record<string, string>
  ): Promise<Tier1RewrittenPrompt> {
    const dna = await this.loadProjectDNA();
    const rewritten = await this.callOllamaStructured<Tier1RewrittenPrompt>(
      dna.agentRouting.models.promptEngineer,
      '.cortex/prompts/tier1-prompt-engineer.system.md',
      '.cortex/schemas/tier1-rewritten-prompt.schema.json',
      {
        rawUserPrompt,
        projectDNA: {
          immutableRules: dna.architecture.immutableRules,
          forbiddenPatterns: dna.architecture.forbiddenPatterns,
          protectedPaths: dna.architecture.protectedPaths,
          codingStandards: dna.codingStandards
        },
        scopedGraphContext,
        preExecOutput
      },
      dna.agentRouting.ollamaBaseUrl
    );

    const scopeLock: TaskScopeLock = {
      activeTaskId: `task_${Date.now()}`,
      taskTitle: rewritten.objective,
      allowedWriteFiles: rewritten.allowedWriteFiles,
      protectedPaths: dna.architecture.protectedPaths,
      forbiddenPatterns: dna.architecture.forbiddenPatterns,
      maxFunctionLines: dna.codingStandards.maxFunctionLines,
      updatedAt: new Date().toISOString()
    };
    await fs.writeFile(
      path.join(this.repoRoot, '.cortex', 'active-task-scope.json'),
      JSON.stringify(scopeLock, null, 2),
      'utf-8'
    );

    return rewritten;
  }

  public async extractTurnMemory(
    platform: string,
    userPrompt: string,
    assistantResponse: string,
    modifiedFiles: string[]
  ): Promise<ExtractedMemoryDelta> {
    const dna = await this.loadProjectDNA();
    return this.callOllamaStructured<ExtractedMemoryDelta>(
      dna.agentRouting.models.memoryExtractor,
      '.cortex/prompts/memory-extractor.system.md',
      '.cortex/schemas/extracted-memory-delta.schema.json',
      { platform, userPrompt, assistantResponse, modifiedFiles },
      dna.agentRouting.ollamaBaseUrl
    );
  }
}
